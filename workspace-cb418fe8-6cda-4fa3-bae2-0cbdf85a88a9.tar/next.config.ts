import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  eslint: {
    ignoreDuringBuilds: true,
  },
  // Exclude API routes from build (they're dynamic routes, don't export as static)
  experimental: {
    excludeRoutes: [
      '/(api)/chat',
      '/(api)/notes',
      '/(api)/reword',
      '/(api)/tasks'
    ]
  },
};

export default nextConfig;
